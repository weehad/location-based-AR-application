package com.lycha.example.augmentedreality;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainHomeActivity extends AppCompatActivity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainhome);
        setTitle("4C4C");
    }

        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.button4:
                    Intent intent = new Intent(getApplicationContext(), CameraViewActivity.class);
                    startActivity(intent);
                    break;
                case R.id.button5:
                    Intent intent2 = new Intent(getApplicationContext(), MapsActivity.class);
                    startActivity(intent2);
                    break;
                case R.id.button6:
                    Intent intent3 = new Intent(getApplicationContext(), ListActivity.class);
                    startActivity(intent3);
                    break;

            }
        }
}
