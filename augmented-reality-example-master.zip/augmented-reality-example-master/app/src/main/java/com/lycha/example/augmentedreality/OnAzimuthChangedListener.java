package com.lycha.example.augmentedreality;

/**
 * Created by krzysztofjackowski on 24/09/15.
 */
public interface OnAzimuthChangedListener {
    void onAzimuthChanged(float azimuthFrom, float azimuthTo);
}
