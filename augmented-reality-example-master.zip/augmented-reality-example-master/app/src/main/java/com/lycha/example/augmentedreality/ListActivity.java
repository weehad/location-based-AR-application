package com.lycha.example.augmentedreality;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class ListActivity extends Activity implements View.OnClickListener {

    private ArrayList<ListViewItem> data = null;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Buildings in DGIST");

        /* xml과 연결 */
        setContentView(R.layout.activity_list);

        ListView listView = (ListView) findViewById(R.id.listview1);

        /*서버와 연동했다면 값을 받아서 띄울 수 있지만,
         *연동이 되어있지 않으므로
         * 하드코딩으로 값을 집어넣는다.
         * listview_item에 정의한 구조대로 값을 넣을 수 있다.
         */

        data = new ArrayList<>();
        //1st item
        ListViewItem list1 = new ListViewItem(R.drawable.ic_launcher_library,
                "Reading & Study Lounge","Library");

        //2nd item
        ListViewItem list2 = new ListViewItem(R.drawable.ic_launcher_consilliancehall,
                "Undergraduate Education", "Consilience Hall");

        //3rd item
        ListViewItem list3 = new ListViewItem(R.drawable.ic_launcher_visselvillage
                , "Students Dormitory" , "Vissel Village");

        //리스트에 추가
        data.add(list1);
        data.add(list2);
        data.add(list3);

        /* 리스트 속의 아이템 연결 */
        ListViewAdapter adapter = new ListViewAdapter(this, R.layout.listview_item, data);
        listView.setAdapter(adapter);

        /* 아이템 클릭시 작동 */
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), ListClicked.class);

                /*putExtra 의 첫 값은 식별 태그, 뒤에는 다음 화면에 넘길 값 */

                startActivity(intent);
            }
        });
    }

        @Override
        public void onClick(View v) {
        }
}


